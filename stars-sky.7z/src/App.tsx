import './App.css';
import { Sky } from "./screens/Sky";

function App() {
  return (
    <>
      <Sky />
    </>
  );
}

export default App;