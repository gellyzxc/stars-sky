declare namespace JSX {
    interface IntrinsicElements {
        [elementName: string]: any;
    }
}