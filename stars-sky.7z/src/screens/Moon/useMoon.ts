export interface IMoonProps {

}

const UseMoon = (): IMoonProps => {
    return (
        {

        }
    );
};

export default UseMoon;